package com.example.ProgLAM;

public class DBStructure {
    public static final String DB_NAME = "EVENTS_DB";
    public static final int DB_VERSION = 6;
    public final static String EVENT_TABLE_NAME = "events_table";
    public final static String EVENT = "event";
    public final static String TIME = "time";
    public final static String DATE = "date";
    public final static String MONTH = "month";
    public final static String YEAR = "year";
    public final static String ID = "ID";
    public final static String NOTIFY = "notify";
    public final static String PRIORITY = "priority";
    public final static String CLASS = "class";
    public final static String STATUS = "status";


}
