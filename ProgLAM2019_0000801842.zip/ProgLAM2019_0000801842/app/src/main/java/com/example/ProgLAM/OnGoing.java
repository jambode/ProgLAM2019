package com.example.ProgLAM;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class OnGoing extends AppCompatActivity {
    DBOpenHelper dbOpenHelper;
    String event;
    String status;
    String id;

    @Override
    protected void onNewIntent(final Intent intent) {
        super.onNewIntent(intent);
        this.setIntent(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle bundle = getIntent().getExtras();
        event = bundle.getString("event");
        status = bundle.getString("status");

        Log.d("myTag", event);
        //Toast.makeText(Completed.this, event + " " + status, Toast.LENGTH_SHORT).show();
        markAsCompleted(event, "ongoing");
        //Toast.makeText(Completed.this, "new:" + status, Toast.LENGTH_SHORT).show();
    }

    private void markAsCompleted(String event, String status){
        dbOpenHelper = new DBOpenHelper(OnGoing.this);
        SQLiteDatabase database = dbOpenHelper.getWritableDatabase();
        dbOpenHelper.markCompleted(event, status, database);
        dbOpenHelper.close();
        //Toast.makeText(Completed.this, "Event Saved", Toast.LENGTH_SHORT).show();
        Toast.makeText(OnGoing.this, event + status, Toast.LENGTH_SHORT).show();
    }

    //private String getEventName(String )
}
