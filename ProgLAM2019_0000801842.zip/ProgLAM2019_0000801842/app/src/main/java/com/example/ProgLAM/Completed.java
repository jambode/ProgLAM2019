package com.example.ProgLAM;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Completed extends AppCompatActivity {

    DBOpenHelper dbOpenHelper;
    String event;
    String status;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getIntent().getExtras();
        event = bundle.getString("event");
        status = bundle.getString("status");
        //Log.d("myTag", status);
        //Toast.makeText(Completed.this, event + " " + status, Toast.LENGTH_SHORT).show();
        markAsCompleted(event, "completed");
        //Toast.makeText(Completed.this, "new:" + status, Toast.LENGTH_SHORT).show();
    }

    private void markAsCompleted(String event, String status){
        dbOpenHelper = new DBOpenHelper(Completed.this);
        SQLiteDatabase database = dbOpenHelper.getWritableDatabase();
        dbOpenHelper.markCompleted(event, status, database);
        dbOpenHelper.close();
        //Toast.makeText(Completed.this, "Event Saved", Toast.LENGTH_SHORT).show();
        Toast.makeText(Completed.this, event + status, Toast.LENGTH_SHORT).show();
    }
}