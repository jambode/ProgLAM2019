package com.example.ProgLAM;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class Postpone extends AppCompatActivity {
    AlertDialog alertDialog;
    DBOpenHelper dbOpenHelper;
    //List<Date> dates = new ArrayList<>();
    Context context;

    String event_Time;
    String event;
    String time;
    String dates;
    String notify;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getIntent().getExtras();
        event = bundle.getString("event");
        time = bundle.getString("time");
        dates = bundle.getString("date");
        notify = bundle.getString("notify");
        Toast.makeText(Postpone.this, event + " " + time + " " + dates + " " + notify, Toast.LENGTH_SHORT).show();
        //setContentView(R.layout.postpone_activity);
        android.app.AlertDialog.Builder builder = new AlertDialog.Builder(Postpone.this);
        builder.setCancelable(true);
        final View postView = LayoutInflater.from(Postpone.this).inflate(R.layout.postpone_activity, null);
        final ImageButton postBtn = postView.findViewById(R.id.post_time);
        final Button saveBtn = postView.findViewById(R.id.post_btn);
        final TextView newtime = postView.findViewById(R.id.newtime);
        postBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int hours = calendar.get(Calendar.HOUR_OF_DAY);
                int minutes = calendar.get(Calendar.MINUTE);
                TimePickerDialog timePickerDialog = new TimePickerDialog(postView.getContext(), R.style.Theme_AppCompat_Dialog, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        Calendar c = Calendar.getInstance();
                        c.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        c.set(Calendar.MINUTE, minute);
                        c.setTimeZone(TimeZone.getDefault());
                        SimpleDateFormat hformat = new SimpleDateFormat("HH:mm a", Locale.ENGLISH);
                        event_Time = hformat.format(c.getTime());

                        newtime.setText(event_Time);

                    }
                }, hours, minutes, false);
                timePickerDialog.show();
            }
        });

       saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    SavePostponedEvent(event, time, dates, notify, event_Time);
                    Calendar calendar = Calendar.getInstance();
                    //int date = calendar.get(Calendar.DAY_OF_MONTH);
                    Toast.makeText(Postpone.this, event + " " +  event_Time + " " +  dates + " " + notify, Toast.LENGTH_SHORT).show();
                    setAlarm(calendar, event, event_Time, getRequestCode(dates, event, event_Time));
                    alertDialog.dismiss();

            }
        });

        builder.setView(postView);
        alertDialog = builder.create();
        alertDialog.show();
    }

    private void SavePostponedEvent(String event, String time, String date, String notify, String new_time){
        dbOpenHelper = new DBOpenHelper(Postpone.this);
        SQLiteDatabase database = dbOpenHelper.getWritableDatabase();
        dbOpenHelper.savePostponedEvent(event, time, date, notify, new_time, database);
        dbOpenHelper.close();
        Toast.makeText(Postpone.this, "Event Saved", Toast.LENGTH_SHORT).show();
        //Toast.makeText(Postpone.this, event + new_time, Toast.LENGTH_SHORT).show();
    }

    private void setAlarm(Calendar calendar, String event, String time, int RequestCode){
        Intent intent = new Intent(Postpone.this.getApplicationContext(), AlarmReceiver.class);
        intent.putExtra("event", event);
        intent.putExtra("time", time);
        intent.putExtra("id", RequestCode);
        //intent.putExtra("priority", prior);
        intent.putExtra("status", "pending");
        PendingIntent pendingIntent = PendingIntent.getBroadcast(Postpone.this, RequestCode, intent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmManager = (AlarmManager) Postpone.this.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

    }

    private int getRequestCode(String date, String event, String time){
        int code = 0;
        dbOpenHelper = new DBOpenHelper(Postpone.this);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        Cursor cursor = dbOpenHelper.ReadIDEvents(date, event, time, database);
        while (cursor.moveToNext()){
            code = cursor.getInt(cursor.getColumnIndex(DBStructure.ID));
        }
        cursor.close();
        dbOpenHelper.close();
        return code;

    }
}