package com.example.ProgLAM;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.view.LineChartView;
import lecho.lib.hellocharts.view.PieChartView;

public class PieChart extends AppCompatActivity {
    DBOpenHelper dbOpenHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        //String value = intent.getStringExtra("key"); //if it's a string you stored.
        setContentView(R.layout.piechart_layout);
        Button nextGraph = findViewById(R.id.nextGraph);

        PieChartView pieChartView = findViewById(R.id.chart);
        List<SliceValue> pieData = new ArrayList<>();
        pieData.add(new SliceValue(getCount("completed"),Color.BLUE).setLabel("Completed"));
        pieData.add(new SliceValue(getCount("pending"), Color.RED).setLabel("Pending"));
        pieData.add(new SliceValue(getCount("ongoing"), Color.MAGENTA).setLabel("Ongoing"));
        //pieData.add(new SliceValue(60, Color.MAGENTA));
        PieChartData pieChartData = new PieChartData(pieData);
        pieChartData.setHasLabels(true);
        pieChartView.setPieChartData(pieChartData);
        //Toast.makeText(PieChart.this, getCount("completed"), Toast.LENGTH_SHORT).show();

        nextGraph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View view = LayoutInflater.from(PieChart.this).inflate(R.layout.linechart_layout, null);
                setContentView(view);
                LineChartView lineChartView = findViewById(R.id.linechart);
                String[] axisData = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
                int[] yAxisData = {getMonthCount("January"),getMonthCount("February"),getMonthCount("March"),getMonthCount("April"),
                        getMonthCount("May"),getMonthCount("June"),getMonthCount("July"), getMonthCount("August"),
                        getMonthCount("September"),getMonthCount("October"),getMonthCount("November"),getMonthCount("December")};
                List yAxisValues = new ArrayList();
                List axisValues = new ArrayList();
                Line line = new Line(yAxisValues);
                line.setColor(R.color.purple);
                for(int i = 0; i < axisData.length; i++){
                    axisValues.add(i, new AxisValue(i).setLabel(axisData[i]));
                }

                for (int i = 0; i < yAxisData.length; i++){
                    yAxisValues.add(new PointValue(i, yAxisData[i]));
                }
                List lines = new ArrayList();
                lines.add(line);

                LineChartData data = new LineChartData();
                data.setLines(lines);
                lineChartView.setLineChartData(data);

                Axis axis = new Axis();
                axis.setValues(axisValues);
                axis.setTextColor(R.color.blue);
                data.setAxisXBottom(axis);


                Axis yAxis = new Axis();
                yAxis.setTextColor(R.color.blue);
                data.setAxisYLeft(yAxis);
            }
        });
    }

    private int getCount(String status){
        int num = 0;
        String ev_stat;
        dbOpenHelper = new DBOpenHelper(PieChart.this);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        Cursor cursor = dbOpenHelper.ReadStatus(status, database);
        while(cursor.moveToNext()){
            ev_stat = cursor.getString(cursor.getColumnIndex(DBStructure.STATUS));
            if(ev_stat.equals(status)){
                num++;
            }
        }
        return num;
    }

    private int getMonthCount(String month){
        int num = 0;
        String ev_month;
        dbOpenHelper = new DBOpenHelper(PieChart.this);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        Cursor cursor = dbOpenHelper.ReadMonth(month, database);
        while(cursor.moveToNext()){
            ev_month = cursor.getString(cursor.getColumnIndex(DBStructure.MONTH));
            if(ev_month.equals(month)){
                num++;
            }
        }
        return num;
    }
}
