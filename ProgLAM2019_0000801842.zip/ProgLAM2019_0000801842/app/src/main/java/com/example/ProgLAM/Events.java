package com.example.ProgLAM;

public class Events {
    String EVENT;
    String TIME;
    String DATE;
    String MONTH;
    String YEAR;
    String PRIORITY;
    String CLASS;
    String STATUS;

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    public String getCLASS() {return CLASS;
    }

    public void setCLASS(String CLASS) {
        this.CLASS = CLASS;
    }


    public String getPRIORITY() {
        return PRIORITY;
    }

    public void setPRIORITY(String PRIORITY) {
        this.PRIORITY = PRIORITY;
    }

    public String getEVENT() {
        return EVENT;
    }

    public void setEVENT(String EVENT) {
        this.EVENT = EVENT;
    }

    public String getTIME() {
        return TIME;
    }

    public void setTIME(String TIME) {
        this.TIME = TIME;
    }

    public String getDATE() {
        return DATE;
    }

    public void setDATE(String DATE) {
        this.DATE = DATE;
    }

    public String getMONTH() {
        return MONTH;
    }

    public void setMONTH(String MONTH) {
        this.MONTH = MONTH;
    }

    public String getYEAR() {
        return YEAR;
    }

    public void setYEAR(String YEAR) {
        this.YEAR = YEAR;
    }

    public Events(String EVENT, String TIME, String DATE, String MONTH, String YEAR, String PRIORITY, String CLASS, String STATUS) {
        this.EVENT = EVENT;
        this.TIME = TIME;
        this.DATE = DATE;
        this.MONTH = MONTH;
        this.YEAR = YEAR;
        this.PRIORITY = PRIORITY;
        this.CLASS = CLASS;
        this.STATUS = STATUS;
    }
}
