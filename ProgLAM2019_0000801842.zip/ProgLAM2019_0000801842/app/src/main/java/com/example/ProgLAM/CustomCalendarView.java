package com.example.ProgLAM;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class CustomCalendarView extends LinearLayout {

    ImageButton nextButton, prevButton;
    Switch fOne, fTwo, fThree;
    Button graphButton;
    TextView currDate;
    GridView gridView;
    private static final int MAX_CALENDAR_DAYS = 42;
    Calendar calendar = Calendar.getInstance(Locale.ENGLISH);
    Context context;
    DBOpenHelper dbOpenHelper;
    String selected_class;
    public static final String postPone = "postPone";
    SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM yyyy", Locale.ENGLISH);
    SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM", Locale.ENGLISH);
    SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy", Locale.ENGLISH);
    SimpleDateFormat eventDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);

    MyGridAdapter myGridAdapter;
    AlertDialog alertDialog;
    List<Date> dates = new ArrayList<>();
    List <Events> eventsList = new ArrayList<>();
    List<Events> filterList = new ArrayList<>();
    int alarmYear, alarmMonth, alarmDay, alarmHour, alarmMinute;



    public CustomCalendarView(Context context) {
        super(context);
    }

    public CustomCalendarView(final Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        InitializeLayout();
        setUpCalendar();

        prevButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar.add(Calendar.MONTH, -1);
                setUpCalendar();
            }
        });

        nextButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar.add(Calendar.MONTH, 1);
                setUpCalendar();
            }
        });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setCancelable(true);
                final View addView = LayoutInflater.from(parent.getContext()).inflate(R.layout.add_newevent_layout, null);
                final EditText EventName = addView.findViewById(R.id.eventid);
                final TextView EventTime = addView.findViewById(R.id.eventtime);
                final EditText PriorityLv = addView.findViewById(R.id.priority);




                //dropdown menu for classes
                Spinner dropdown = addView.findViewById(R.id.dropdown);
                String[] items = new String[]{"Work", "Family", "Leisure"};
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_dropdown_item, items);
                dropdown.setAdapter(adapter);

                //dropdown selects class
                dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        //Toast.makeText(context, parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();
                        selected_class = parent.getItemAtPosition(position).toString();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                //variables for time
                ImageButton SetTime = addView.findViewById(R.id.set_time);
                Button AddEvent = addView.findViewById(R.id.add_event);
                final CheckBox notifyMe = addView.findViewById(R.id.alarmme);
                Calendar dateCalendar = Calendar.getInstance();
                dateCalendar.setTime(dates.get(position));
                alarmYear = dateCalendar.get(Calendar.YEAR);
                alarmMonth = dateCalendar.get(Calendar.MONTH);
                alarmDay = dateCalendar.get(Calendar.DAY_OF_MONTH);

                final String date = eventDateFormat.format(dates.get(position));
                final String month = monthFormat.format(dates.get(position));
                final String year = yearFormat.format(dates.get(position));

                //set reminder time
                SetTime.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar = Calendar.getInstance();
                        int hours = calendar.get(Calendar.HOUR_OF_DAY);
                        int minutes = calendar.get(Calendar.MINUTE);
                        TimePickerDialog timePickerDialog = new TimePickerDialog(addView.getContext(), R.style.Theme_AppCompat_Dialog, new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                Calendar c = Calendar.getInstance();
                                c.set(Calendar.HOUR_OF_DAY, hourOfDay);
                                c.set(Calendar.MINUTE, minute);
                                c.setTimeZone(TimeZone.getDefault());
                                SimpleDateFormat hformat = new SimpleDateFormat("HH:mm a", Locale.ENGLISH);
                                String event_Time = hformat.format(c.getTime());

                                EventTime.setText(event_Time);
                                alarmHour = c.get(Calendar.HOUR_OF_DAY);
                                alarmMinute = c.get(Calendar.MINUTE);



                            }
                        }, hours, minutes, false);
                        timePickerDialog.show();
                    }
                });


                //add event
                AddEvent.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if(notifyMe.isChecked()) {
                            SaveEvent(EventName.getText().toString(), EventTime.getText().toString(), date, month, year, "on", PriorityLv.getText().toString(), selected_class, "pending");
                            setUpCalendar();
                            Calendar calendar = Calendar.getInstance();
                            calendar.set(alarmYear, alarmMonth, alarmDay, alarmHour, alarmMinute);
                            setAlarm(calendar, EventName.getText().toString(), EventTime.getText().toString(), date, PriorityLv.getText().toString(), "on", getRequestCode(date, EventName.getText().toString(), EventTime.getText().toString()));
                            alertDialog.dismiss();
                        }
                        else {
                            SaveEvent(EventName.getText().toString(), EventTime.getText().toString(), date, month, year, "off", PriorityLv.getText().toString(), selected_class, "pending");
                            setUpCalendar();
                            alertDialog.dismiss();
                        }
                    }
                });

                builder.setView(addView);
                alertDialog = builder.create();
                alertDialog.show();
            }
        });

        //FILTRO NOTIFICHE
        fOne.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(buttonView.isChecked()) {
                    int code;
                    String priority;
                    dbOpenHelper = new DBOpenHelper(context);
                    SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
                    Cursor cursor = dbOpenHelper.ReadIDEventsPrior("on", database);
                    while (cursor.moveToNext()) {
                        priority = cursor.getString(cursor.getColumnIndex(DBStructure.PRIORITY));
                        if (priority.equals("1")) {
                            Log.d("myTag", cursor.getString(cursor.getColumnIndex(DBStructure.ID)) + cursor.getString(cursor.getColumnIndex(DBStructure.PRIORITY)));
                        } else {
                            //Toast.makeText(context, "cioa", Toast.LENGTH_SHORT).show();
                            code = cursor.getInt(cursor.getColumnIndex(DBStructure.ID));
                            //Log.d("myTag2", cursor.getString(cursor.getColumnIndex(DBStructure.ID)) + cursor.getString(cursor.getColumnIndex(DBStructure.PRIORITY)));
                            cancelAlarm(code);
                        }
                    }

                    cursor.close();
                    dbOpenHelper.close();
                }
            }
        });

        //only priority two
        fTwo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(buttonView.isChecked()) {
                    int code;
                    String priority;
                    dbOpenHelper = new DBOpenHelper(context);
                    SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
                    Cursor cursor = dbOpenHelper.ReadIDEventsPrior("on", database);
                    while (cursor.moveToNext()) {
                        priority = cursor.getString(cursor.getColumnIndex(DBStructure.PRIORITY));
                        if (priority.equals("2")) {
                            Log.d("myTag", cursor.getString(cursor.getColumnIndex(DBStructure.ID)) + cursor.getString(cursor.getColumnIndex(DBStructure.PRIORITY)));
                        } else {
                            //Toast.makeText(context, "cioa", Toast.LENGTH_SHORT).show();
                            code = cursor.getInt(cursor.getColumnIndex(DBStructure.ID));
                            //Log.d("myTag2", cursor.getString(cursor.getColumnIndex(DBStructure.ID)) + cursor.getString(cursor.getColumnIndex(DBStructure.PRIORITY)));
                            cancelAlarm(code);
                        }
                    }

                    cursor.close();
                    dbOpenHelper.close();
                }
            }
        });

        //only priority three
        fThree.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(buttonView.isChecked()) {
                    int code;
                    String priority;
                    dbOpenHelper = new DBOpenHelper(context);
                    SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
                    Cursor cursor = dbOpenHelper.ReadIDEventsPrior("on", database);
                    while (cursor.moveToNext()) {
                        priority = cursor.getString(cursor.getColumnIndex(DBStructure.PRIORITY));
                        if (priority.equals("3")) {
                            Log.d("myTag", cursor.getString(cursor.getColumnIndex(DBStructure.ID)) + cursor.getString(cursor.getColumnIndex(DBStructure.PRIORITY)));
                        } else {
                            //Toast.makeText(context, "cioa", Toast.LENGTH_SHORT).show();
                            code = cursor.getInt(cursor.getColumnIndex(DBStructure.ID));
                            //Log.d("myTag2", cursor.getString(cursor.getColumnIndex(DBStructure.ID)) + cursor.getString(cursor.getColumnIndex(DBStructure.PRIORITY)));
                            cancelAlarm(code);
                        }
                    }

                    cursor.close();
                    dbOpenHelper.close();
                }
            }
        });

        graphButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(context, PieChart.class);
                context.startActivity(myIntent);
            }
        });

                gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                        final String date = eventDateFormat.format(dates.get(position));
                        //TextView noEv = view.findViewById(R.id.EventsRV);

                        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setCancelable(true);
                        final View showView = LayoutInflater.from(parent.getContext()).inflate(R.layout.show_events_layout, null);
                        final RecyclerView recyclerView = showView.findViewById(R.id.EventsRV);
                        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(showView.getContext());
                        recyclerView.setLayoutManager(layoutManager);
                        recyclerView.setHasFixedSize(true);
                        final EventRecyclerAdapter eventRecyclerAdapter = new EventRecyclerAdapter(showView.getContext(),CollectEventsByDate(date));
                        recyclerView.setAdapter(eventRecyclerAdapter);
                        eventRecyclerAdapter.notifyDataSetChanged();

                        Switch workBtn = showView.findViewById(R.id.workSwitch);
                        Switch famBtn = showView.findViewById(R.id.familySwitch);
                        Switch leisBtn = showView.findViewById(R.id.leisureSwitch);

                        workBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                if(isChecked){
                                    //Toast.makeText(context, "checked", Toast.LENGTH_SHORT).show();
                                    final RecyclerView recyclerView1 = showView.findViewById(R.id.EventsRV);
                                    EventRecyclerAdapter eventRecyclerAdapter1 = new EventRecyclerAdapter(showView.getContext(),CollectEventsByClass("Work", date));
                                    recyclerView1.setAdapter(eventRecyclerAdapter1);
                                    eventRecyclerAdapter1.notifyDataSetChanged();


                                }
                                else {
                                    Toast.makeText(context, "disabled", Toast.LENGTH_SHORT).show();
                                    final EventRecyclerAdapter eventRecyclerAdapter = new EventRecyclerAdapter(showView.getContext(),CollectEventsByDate(date));
                                    recyclerView.setAdapter(eventRecyclerAdapter);
                                    eventRecyclerAdapter.notifyDataSetChanged();
                                }
                            }
                        });

                        famBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                if(isChecked){
                                    //Toast.makeText(context, "checked", Toast.LENGTH_SHORT).show();
                                    final RecyclerView recyclerView1 = showView.findViewById(R.id.EventsRV);
                                    EventRecyclerAdapter eventRecyclerAdapter1 = new EventRecyclerAdapter(showView.getContext(),CollectEventsByClass("Family", date));
                                    recyclerView1.setAdapter(eventRecyclerAdapter1);
                                    eventRecyclerAdapter1.notifyDataSetChanged();


                                }
                                else {
                                    Toast.makeText(context, "disabled", Toast.LENGTH_SHORT).show();
                                    final EventRecyclerAdapter eventRecyclerAdapter = new EventRecyclerAdapter(showView.getContext(),CollectEventsByDate(date));
                                    recyclerView.setAdapter(eventRecyclerAdapter);
                                    eventRecyclerAdapter.notifyDataSetChanged();
                                }
                            }
                        });

                        leisBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                if(isChecked){
                                    //Toast.makeText(context, "checked", Toast.LENGTH_SHORT).show();
                                    final RecyclerView recyclerView1 = showView.findViewById(R.id.EventsRV);
                                    EventRecyclerAdapter eventRecyclerAdapter1 = new EventRecyclerAdapter(showView.getContext(),CollectEventsByClass("Leisure", date));
                                    recyclerView1.setAdapter(eventRecyclerAdapter1);
                                    eventRecyclerAdapter1.notifyDataSetChanged();


                                }
                                else {
                                    Toast.makeText(context, "disabled", Toast.LENGTH_SHORT).show();
                                    final EventRecyclerAdapter eventRecyclerAdapter = new EventRecyclerAdapter(showView.getContext(),CollectEventsByDate(date));
                                    recyclerView.setAdapter(eventRecyclerAdapter);
                                    eventRecyclerAdapter.notifyDataSetChanged();
                                }
                            }
                        });

                        builder.setView(showView);
                        alertDialog = builder.create();
                        alertDialog.show();

                        //we need to delete the deleted event from the calendar view
                        alertDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override
                            public void onCancel(DialogInterface dialog) {
                                setUpCalendar();
                            }
                        });
                        return true;

                    }
                });
    }


    private void cancelAlarm(int RequestCode){
        Intent intent = new Intent(context.getApplicationContext(), AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, RequestCode, intent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmManager = (AlarmManager) context.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(pendingIntent);
    }


    private int getRequestCode(String date, String event, String time){
        int code = 0;
        dbOpenHelper = new DBOpenHelper(context);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        Cursor cursor = dbOpenHelper.ReadIDEvents(date, event, time, database);
        while (cursor.moveToNext()){
            code = cursor.getInt(cursor.getColumnIndex(DBStructure.ID));
        }
        cursor.close();
        dbOpenHelper.close();
        return code;

    }


    private void setAlarm(Calendar calendar, String event, String time, String date, String prior, String notify, int RequestCode){
        Intent intent = new Intent(context.getApplicationContext(), AlarmReceiver.class);
        intent.putExtra("event", event);
        intent.putExtra("time", time);
        intent.putExtra("date", date);
        intent.putExtra("id", RequestCode);
        intent.putExtra("priority", prior);
        intent.putExtra("status", "pending");
        intent.putExtra("notify", notify);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, RequestCode, intent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmManager = (AlarmManager) context.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

    }


    private ArrayList<Events> CollectEventsByDate(String date){
        ArrayList<Events> arrayList;
        arrayList = new ArrayList<>();
        dbOpenHelper = new DBOpenHelper(context);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        Cursor cursor = dbOpenHelper.ReadEvents(date, database);
        while (cursor.moveToNext()){
            String event = cursor.getString(cursor.getColumnIndex(DBStructure.EVENT));
            String time = cursor.getString((cursor.getColumnIndex(DBStructure.TIME)));
            String Date = cursor.getString((cursor.getColumnIndex(DBStructure.DATE)));
            String month = cursor.getString((cursor.getColumnIndex(DBStructure.MONTH)));
            String Year = cursor.getString((cursor.getColumnIndex(DBStructure.YEAR)));
            String priority = cursor.getString((cursor.getColumnIndex(DBStructure.PRIORITY)));
            String ev_class = cursor.getString((cursor.getColumnIndex(DBStructure.CLASS)));
            String status = cursor.getString((cursor.getColumnIndex(DBStructure.STATUS)));
            Events events = new Events(event, time, Date, month, Year, priority, ev_class, status);
            //String times = events.getCLASS();
            //Toast.makeText(context, times, Toast.LENGTH_SHORT).show();
            arrayList.add(events);
        }
        cursor.close();
        dbOpenHelper.close();

        return arrayList;
    }

    private ArrayList<Events> CollectEventsByClass(String event_class, String date){
        ArrayList<Events> arrayList;
        arrayList = new ArrayList<>();
        dbOpenHelper = new DBOpenHelper(context);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        Cursor cursor = dbOpenHelper.ReadClassEvents(event_class, date, database);
        while (cursor.moveToNext()){
                String event = cursor.getString(cursor.getColumnIndex(DBStructure.EVENT));
                String time = cursor.getString((cursor.getColumnIndex(DBStructure.TIME)));
                String Date = cursor.getString((cursor.getColumnIndex(DBStructure.DATE)));
                String month = cursor.getString((cursor.getColumnIndex(DBStructure.MONTH)));
                String Year = cursor.getString((cursor.getColumnIndex(DBStructure.YEAR)));
                String ev_class = cursor.getString((cursor.getColumnIndex(DBStructure.CLASS)));
                String priority = cursor.getString((cursor.getColumnIndex(DBStructure.PRIORITY)));
                String status = cursor.getString((cursor.getColumnIndex(DBStructure.STATUS)));
                Events events = new Events(event, time, Date, month, Year, priority, ev_class, status);
                //String times = events.getCLASS();
                //Toast.makeText(context, times, Toast.LENGTH_SHORT).show();
                arrayList.add(events);

        }
        cursor.close();
        dbOpenHelper.close();

        return arrayList;
    }

    public CustomCalendarView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private void SaveEvent(String event, String time, String date, String month, String year, String notify, String prior_num, String ev_class, String status){
        dbOpenHelper = new DBOpenHelper(context);
        SQLiteDatabase database = dbOpenHelper.getWritableDatabase();
        dbOpenHelper.saveEvent(event, time, date, month, year, notify, prior_num, ev_class, status, database);
        dbOpenHelper.close();
        Toast.makeText(context, "Event Saved", Toast.LENGTH_SHORT).show();
    }

    private void InitializeLayout(){
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.calendar_layout, this);
        nextButton = view.findViewById(R.id.nextBtn);
        prevButton = view.findViewById(R.id.previousBtn);
        currDate = view.findViewById(R.id.CurrentDate);
        fOne = view.findViewById(R.id.onebutton);
        fTwo = view.findViewById(R.id.twobutton);
        fThree = view.findViewById(R.id.threebutton);
        graphButton = view.findViewById(R.id.showGraph);
        gridView = view.findViewById(R.id.gridView);
    }

    private void setUpCalendar(){
        String currentDate = dateFormat.format(calendar.getTime());
        currDate.setText(currentDate);
        dates.clear();
        Calendar monthcalendar = (Calendar) calendar.clone();
        monthcalendar.set(Calendar.DAY_OF_MONTH, 1);
        int FirstDay = monthcalendar.get(Calendar.DAY_OF_WEEK) -1;
        monthcalendar.add(Calendar.DAY_OF_MONTH, -FirstDay);
        String currentMonth = monthFormat.format(calendar.getTime());
        String currentYear = yearFormat.format(calendar.getTime());
        CollectEventsPerMonth(currentMonth, currentYear);


        while (dates.size() < MAX_CALENDAR_DAYS){
            dates.add(monthcalendar.getTime());
            monthcalendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        myGridAdapter = new MyGridAdapter(context, dates, calendar, eventsList);
        gridView.setAdapter(myGridAdapter);
    }

    private void CollectEventsPerMonth(String Month, String year){
        eventsList.clear();
        dbOpenHelper = new DBOpenHelper(context);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        Cursor cursor = dbOpenHelper.ReadEventsperMonth(Month, year, database);
        while (cursor.moveToNext()){
           String event = cursor.getString(cursor.getColumnIndex(DBStructure.EVENT));
           String time = cursor.getString((cursor.getColumnIndex(DBStructure.TIME)));
           String date = cursor.getString((cursor.getColumnIndex(DBStructure.DATE)));
           String month = cursor.getString((cursor.getColumnIndex(DBStructure.MONTH)));
           String Year = cursor.getString((cursor.getColumnIndex(DBStructure.YEAR)));
           //String priority = cursor.getString((cursor.getColumnIndex(DBStructure.PRIORITY)));
           Events events = new Events(event, time, date, month, Year, "null", "null", "null");
           //String times = events.getTIME();
           //Toast.makeText(context, times, Toast.LENGTH_LONG).show();
           eventsList.add(events);
        }

        cursor.close();
        dbOpenHelper.close();
    }
}
