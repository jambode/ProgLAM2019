package com.example.ProgLAM;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;


public class AlarmReceiver extends BroadcastReceiver {
    int requestID = (int) System.currentTimeMillis();
    @Override
    public void onReceive(Context context, Intent intent) {
        String event = intent.getStringExtra("event");
        String time = intent.getStringExtra("time");
        String date = intent.getStringExtra("date");
        String status = intent.getStringExtra("status");
        String notify = intent.getStringExtra("notify");
        int notId = intent.getIntExtra("id", 0 );
        Intent activityIntent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, requestID, activityIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_ONE_SHOT);

        //intent to postpone event
        Intent postPone = new Intent(context, Postpone.class);
        postPone.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        postPone.putExtra("event", event);
        postPone.putExtra("time", time);
        postPone.putExtra("notify", notify);
        postPone.putExtra("date", date);
        PendingIntent postPending = PendingIntent.getActivity(context, requestID +1 , postPone, PendingIntent.FLAG_UPDATE_CURRENT);

        //intent of ongoing event
        Intent onGoing = new Intent(context, OnGoing.class);
        onGoing.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        onGoing.putExtra("event", event);
        onGoing.putExtra("time", time);
        onGoing.putExtra("status", status);
        PendingIntent ongoing = PendingIntent.getActivity(context, requestID +2 , onGoing, PendingIntent.FLAG_UPDATE_CURRENT);

        //intent to complete event
        Intent markCompleted = new Intent(context, Completed.class);
        markCompleted.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        markCompleted.putExtra("event", event);
        markCompleted.putExtra("time", time);
        markCompleted.putExtra("status", status);
        PendingIntent mark = PendingIntent.getActivity(context, requestID +3 , markCompleted, PendingIntent.FLAG_UPDATE_CURRENT);

        String channelId = "channel_id";
        CharSequence name = "channel_name";
        String description = "description";
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel(channelId, name, NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription(description);
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }


        Notification notification = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_stat_name)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setContentTitle(event)
                .setContentText(time)
                .setDeleteIntent(pendingIntent)
                .setGroup("Group_calendar_view")
                .addAction(R.drawable.ic_stat_name, "Postpone", postPending)
                .addAction(R.drawable.ic_stat_name, "Ongoing", ongoing)
                .addAction(R.drawable.ic_stat_name, "Completed", mark)
                .build();
        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(context);
        notificationManagerCompat.notify(notId, notification);

    }
}
