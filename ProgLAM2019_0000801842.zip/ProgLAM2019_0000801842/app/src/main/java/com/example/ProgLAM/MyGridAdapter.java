package com.example.ProgLAM;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MyGridAdapter extends ArrayAdapter {

    List<Date> dates;
    Calendar currentDate;
    List<Events> events;
    LayoutInflater inflater;

    @Nullable
    @Override
    public Object getItem(int position) {
        return dates.get(position);
    }

    @Override
    public int getPosition(Object item) {
        return dates.indexOf(item);
    }

    @Override
    public int getCount() {
        return dates.size();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Date monthDate = dates.get(position);
        Calendar dateCalendar = Calendar.getInstance();
        dateCalendar.setTime(monthDate);
        int dayNum = dateCalendar.get(Calendar.DAY_OF_MONTH);
        int displayMonth = dateCalendar.get(Calendar.MONTH) +1;
        int displayYear = dateCalendar.get(Calendar.YEAR);
        int currMonth = currentDate.get(Calendar.MONTH) +1 ;
        int currYear = currentDate.get(Calendar.YEAR);
        int currDay = currentDate.get(Calendar.DAY_OF_MONTH);
        View view = convertView;

        if (view == null) {
            view = inflater.inflate(R.layout.single_cell_layout, parent, false);
        }

        if(dayNum == currDay && displayMonth == currMonth) {
            view.setBackgroundColor(getContext().getResources().getColor(R.color.pink));
        }
        else if (displayMonth == currMonth && displayYear == currYear) {
            view.setBackgroundColor(getContext().getResources().getColor(R.color.darkPink));
        } else {
            view.setBackgroundColor(getContext().getResources().getColor(R.color.fadedPink));
        }

        TextView day_num = view.findViewById(R.id.calendar_day);
        TextView event_num = view.findViewById(R.id.events_id);
        event_num.setTextColor(getContext().getResources().getColor(R.color.black));
        day_num.setText(String.valueOf(dayNum));
        Calendar eventsCalendar = Calendar.getInstance();
        ArrayList<String> arrayList = new ArrayList<>();

        for (int i = 0; i < events.size(); i++) {
            eventsCalendar.setTime(ConvertStringToDate(events.get(i).getDATE()));
            if (dayNum == eventsCalendar.get(Calendar.DAY_OF_MONTH) && displayMonth == eventsCalendar.get(Calendar.MONTH) + 1
                    && displayYear == eventsCalendar.get(Calendar.YEAR)) {
                arrayList.add(events.get(i).getEVENT());
                //Toast.makeText(getContext(), arrayList.size(), Toast.LENGTH_SHORT);

                if(arrayList.size() == 1) {
                    event_num.setText(arrayList.size() + " Event");
                }
                else {
                    event_num.setText(arrayList.size() + " Events");
                }
            }
        }

        return view;

    }

    private Date ConvertStringToDate(String eventDate) {
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy", Locale.ITALIAN);
        Date date = null;
        try {
            date = format.parse(eventDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    public MyGridAdapter(@NonNull Context context, List<Date> dates, Calendar currentDate, List<Events> events) {
        super(context, R.layout.single_cell_layout);

        this.dates = dates;
        this.currentDate = currentDate;
        this.events = events;
        inflater = LayoutInflater.from(context);
    }
}
